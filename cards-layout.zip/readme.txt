=== Cards Layout ===
Contributors: bplugins, abuhayat, asadsuzan, btechnologies
Donate link: https://www.buymeacoffee.com/abuhayat
Tags: block, cards, showcase, blogcard, grid
Requires at least: 6.5
Tested up to: 7.0
Stable tag: 2.0.3
Requires PHP: 7.4
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html


Build responsive, customizable card components with multiple layouts and dynamic styles in the Gutenberg editor.

== Description ==

Cards Layout is a powerful and flexible WordPress Gutenberg block plugin designed to help you create stunning, professional-grade card components in seconds. 

Whether you need to highlight core features, showcase team profiles, display achievement metrics, or present your skill progress, Cards Layout provides a rich set of beautifully crafted, responsive components to elevate your website's design.


[**Cards Layout**](https://bplugins.com/products/cards-layout/) | [**Pricing**](https://bplugins.com/products/cards-layout/pricing) | [**Support**](https://wordpress.org/support/plugin/cards-layout//) | [**Demos**](https://bplugins.com/products/cards-layout/#demos)

== Key Features ==
* **Default Card:** The perfect minimal card for general content, featuring image, title, description, and button controls.

* **Hero Feature Card:** A prominent split-design card with advanced image focal point controls, overlay gradients, floating notification badges, and floating stat highlights.

* **Achievement Card:** Highlight your biggest wins with a large central metric and a customizable spinning SVG badge animation.

* **Feature Card:** A sleek, modern card layout perfect for highlighting key features or benefits.

* **Responsive Grid Engine:** Native control over column counts (Desktop, Tablet, Mobile) and gap spacing to build perfect grids instantly.

* **Advanced Global Styling:** Granular control over everything from typography (fonts, sizes, weights) to multi-state box shadows, borders, padding, and alignments.

== Pro Features  ==
The following premium layouts and advanced features are available exclusively in the standalone **Cards Layout Pro** plugin (available on our website). These features are not included in this free version and require the separate Pro plugin to be installed.

* **State / Counter Card:** Create dynamic statistic cards featuring up/down trend ribbons and customizable visual sparkline graphs.

* **Progress Card:** Display skill levels or project progress with customizable gradient bars and individual metric tracking.
* **Animated Service Card:** Stand out with glowing, animated border gradients and dynamic hover growth effects.

* **Banner Card:** Build full-width promotional banners featuring stunning "Glassmorphism" blur effects and custom eyebrow taglines.

* **Client Logo Card:** Professionally present brand partners with specialized minimal typographic cards and distinct hover color interactions.

* **Creative Curve Card:** A highly stylized layout with a seamless CSS-curve cutout connecting your icon to your text content.
* **Feature Card:** Premium, sleek layout for displaying software or service features.


== Feedback & Support ==

Did you find a bug or have a feature request?  
💁‍♂️ [Please share your feedback with us](mailto:support@bplugins.com)


###  Check out our other WordPress Plugins

 🎵**[Html5 Audio Player](https://bplugins.com/products/html5-audio-player)** – Best audio player plugin for WordPress.

🎬 **[Html5 Video Player](https://bplugins.com/products/html5-video-player)** – Best video player plugin for WordPress.

📄**[PDF Poster](https://bplugins.com/products/pdf-poster)** – A fully-featured PDF Viewer Plugin for WordPress.

📑**[Document Embedder](https://bplugins.com/products/document-embedder)** – Best WordPress Document Embedder Plugin.

🧊**[3D Viewer](https://bplugins.com/products/3d-viewer)** – Display interactive 3D models on the webs.

📰**[Advanced Post Block](https://bplugins.com/products/advanced-post-block)** – Best Post Display Plugin for WordPress.



== Installation ==

### From Gutenberg Editor:
1. Go to the WordPress Block/Gutenberg Editor
2. Search For **Cards Layout**
3. Click on the **Cards Layout** to add the block

### Download & Upload:
1. Download the **Cards Layout** plugin (*.zip file*)
2. In your admin area, go to the Plugins menu and click on **Add New**
3. Click on **Upload Plugin** and choose the **`cards-layout.zip`** file and click on **Install Now**
4. Activate the plugin and Enjoy!

### Manually:
1. Download and upload the **Cards Layout** plugin to the **`/wp-content/plugins/`** directory
2. Activate the plugin through the Plugins menu in WordPress


== Frequently Asked Questions ==

= Does it work with any WordPress theme? =

Yes, it will work with any standard WordPress theme.

= Can I change block settings? =

Yes, you can change block settings from the Gutenberg block editor's right sidebar.

= How many times can I reuse a block? =

You can use unlimited times as you want.

= Where can I get support? =

You can post your questions on the [support forum here](https://wordpress.org/support/plugin/cards-layout/)


== Screenshots ==

1. Settings
2. Default Design
3. Hero Feature Card
4. Achievement Card
5. Feature Card

== Upgrade Notice ==

= 2.0.3 =
This version includes critical updates to comply with WordPress.org guidelines by removing external image CDN requests and updating the internal file architecture. We highly recommend upgrading to this version immediately.

= 2.0.2 =
Major compliance update. Removed all trialware, locked features, and gated premium logic from the free plugin to strictly adhere to WordPress.org guidelines. 

== Changelog ==

= 2.0.3 – 4 June, 2026 =
* Removed free-version frontend attribute restrictions that could be interpreted as locked functionality.
* Refactored frontend rendering logic to ensure all available free features remain fully functional.
* Fixed invalid GitHub repository URL in readme documentation.
* Added complete External Services documentation for bPlugins API usage, including purpose, transmitted data, Terms of Service, and Privacy Policy references.
* Improved shortcode rendering and output sanitization following WordPress security and escaping best practices.
* Performed additional codebase audit for WordPress.org Plugin Directory compliance.
* Updated plugin documentation and metadata.
* General code cleanup and maintenance improvements.


= 2.0.2 – 13 May, 2026 =

* Removed all Freemius-based feature gating and premium license checks from the plugin codebase.
* Removed locked/blurred Pro-only layouts and any restricted built-in functionality to comply with WordPress.org Guideline #5 (Trialware).
* Removed `PHCLB_HAS_PRO`, `cl_fs()->can_use_premium_code()`, and related conditional premium access logic.
* Cleaned block editor, admin dashboard, and frontend UI from upgrade-lock states and restricted feature handling.
* Updated plugin architecture to ensure all included features are fully functional without license activation.
* Added publicly accessible source code references and development documentation in the plugin readme.
* Included documentation for build tools and asset generation workflow for JavaScript/CSS files.
* Ensured generated assets in `/build` have corresponding human-readable source files available.
* Improved plugin compliance with WordPress.org Guideline #4 (Human Readable Code).
* Performed a full plugin audit for WordPress coding standards, security, and repository compliance.
* Tested plugin on a clean WordPress installation with `WP_DEBUG` enabled.
* General code cleanup, optimization, and maintenance improvements.


= 2.0.1 – 26 April, 2026 =
* Enhanced block title for clearer identification.
* Improved user interface for better accessibility.

= 2.0.0 – 21 April, 2026 =
* Major Release: Introducing a new layout engine!
* New Layouts: Hero Feature Card, Achievement Card, Feature Card.
* Added Responsive Grid Engine for Desktop, Tablet, and Mobile column controls.
* Added granular Icon Wrap Size controls for independent scaling.
* Added dynamic Card Tags across multiple layouts.
* Added customizable badge animation speed for Achievement Card.
* Codebase optimization and bug fixes.

= 1.1.4 – 29 July, 2025 =
* focalPoint added good feature;

= 1.1.3 – 27 July, 2025 =
* Import content from image media;

= 1.1.2 – 9 July, 2025 =
* Image border radius and card content align option added

= 1.1.1 – 6 July, 2025 =
* Card URL and button URL now open in a new tab;

= 1.1.0 – 4 July, 2025 =
* Default layout available
* Set card border, padding, and border radius
* Customize card title, description, and button typography, color, padding, and border radius

= 1.0.0 =
* Initial Release



== Source Code ==

Contribute, report bugs, or view the source code on GitHub  👉
[**Cards Layout GitHub**](https://github.com/bPlugins/cards-layout-free)

== External Services ==
This plugin bundles the following third-party JavaScript/PHP libraries.

= bPlugins Products API =
- Endpoint: https://api.bplugins.com/
- Used for: Displaying pricing and product information in the admin dashboard.
- Data sent: Plugin ID (non-personal), no user data.
- Terms of Service: https://bplugins.com/terms-of-service/
- Privacy Policy: https://bplugins.com/privacy-policy/

= Freemius (wp.freemius.com) =
- Endpoint: https://wp.freemius.com/
- Used for: Processing plugin opt-in consent form submissions.
- Data sent: Only after explicit user opt-in — user name, email, site URL, WP/PHP version, plugin version.
- Terms of Service: https://freemius.com/terms/
- Privacy Policy: https://freemius.com/privacy/

= SVG Icons (Font Awesome, Lucide, etc.) = 
 - Purpose: Provides scalable vector icons used for UI elements.
 - Note: This plugin does not load the full Font Awesome or Lucide libraries. Instead, specific icons are included directly as    inline SVGs in the source code to keep the plugin lightweight and performant.

= WordPress.org Plugins API =

- Service: WordPress.org Plugins Info API – `https://api.wordpress.org`
- What it does: The dashboard queries the public WordPress.org Plugins API to list other plugins published by the author (titles, icons, ratings, active installs, etc.).
- What data is sent: A public, read-only query request (e.g. `https://api.wordpress.org/plugins/info/1.2/?action=query_plugins&request[author]=bplugins`). No personal data is sent.
- When: Only while an administrator is viewing the plugin's dashboard in wp-admin.
- Terms of Service: [https://wordpress.org/about/privacy/](https://wordpress.org/about/privacy/)
- Privacy Policy: [https://wordpress.org/about/privacy/](https://wordpress.org/about/privacy/)

== Third-Party Libraries ==

= Immer =
- Version: 11.1.8
- Source: [https://immerjs.github.io/immer/](https://immerjs.github.io/immer/)
- GitHub: [https://github.com/immerjs/immer](https://github.com/immerjs/immer)
- License: MIT
- Purpose: Used for managing immutable state in a more convenient way.


= React Router DOM =
- Version: 7.15.0
- Source: [https://reactrouter.com/]( https://reactrouter.com/)
- GitHub: [https://github.com/remix-run/react-router](https://github.com/remix-run/react-router)
- License: MIT
- License URL: [https://github.com/remix-run/react-router/blob/main/LICENSE.md](https://github.com/remix-run/react-router/blob/main/LICENSE.md)
- Purpose: Used for client-side routing and navigation within the plugin's React-based admin application and settings interface.
- External Services: None. React Router DOM operates entirely within the browser and does not communicate with external services.

= bpl-tools =
- Source / GitHub: [https://github.com/bPlugins/bpl-tools](https://github.com/bPlugins/bpl-tools)
- License: GPL-2.0-or-later: [https://www.gnu.org/licenses/gpl-2.0.html](https://www.gnu.org/licenses/gpl-2.0.html)
- Purpose: Shared utility library providing admin dashboard components and common Gutenberg editor controls.
- External Services: The library may connect to bPlugins, WordPress.org, and Freemius services for product data and checkout functionality. See full details: [https://github.com/bPlugins/bpl-tools#external-requests--why-they-are-made](https://github.com/bPlugins/bpl-tools#external-requests--why-they-are-made)

= Freemius Lite SDK =
- Version: 2.2.0
- Source: [https://bplugins.com/](https://bplugins.com/)
- GitHub: [https://github.com/bPlugins/freemius-lite-sdk](https://github.com/bPlugins/freemius-lite-sdk)
- License: GPL-2.0-or-later – [https://www.gnu.org/licenses/gpl-2.0.html](https://www.gnu.org/licenses/gpl-2.0.html)
- Purpose: Provides an opt-in consent form for usage tracking and analytics to help improve the plugin. No data is sent before explicit user consent.
- External Services: Communicates with `api.bplugins.com` (activation events) and `wp.freemius.com` (opt-in processing) only after user opt-in. See [bPlugins Privacy Policy](https://bplugins.com/privacy-policy) and [Freemius Privacy Policy](https://freemius.com/privacy/).


